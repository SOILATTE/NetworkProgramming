package org.project.nameko;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

public class ExplainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_GRANDPA= 501;
    public static final int REQUEST_CODE_FARM= 502;
    public static final int REQUEST_CODE_BOOK= 503;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explain);

        ImageView grandpaImageView = findViewById(R.id.menuGrandpaImage);
        grandpaImageView.setOnClickListener(v ->  {
            Intent intent = new Intent(getApplicationContext(), GrandpaActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivityForResult(intent,REQUEST_CODE_GRANDPA);
        });

        ImageView farmImageView = findViewById(R.id.menuFarmSelectedImage);
        farmImageView.setOnClickListener(v ->  {
            Intent intent = new Intent(getApplicationContext(), FarmActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivityForResult(intent,REQUEST_CODE_FARM);
        });

        ImageView bookImageView = findViewById(R.id.menuBookImage);
        bookImageView.setOnClickListener(v ->  {
            Intent intent = new Intent(getApplicationContext(), BookActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivityForResult(intent,REQUEST_CODE_BOOK);
        });

        Toast.makeText(this,"설명 액티비티 create",Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Toast.makeText(this, "설명 액티비티 onNewIntent", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "설명 액티비티 destroy", Toast.LENGTH_LONG).show();
    }

}